package com.blog.application.blog.services.impl;

public class page<T> {

}
